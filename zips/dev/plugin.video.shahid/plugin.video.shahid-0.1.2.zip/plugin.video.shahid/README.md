# Shahid Kodi plguin

Live Streaming, VOD, Shahid, TV Shows and TV Programs from https://shahid.mbc.net/

## Install tips
 - You can install this plugin by downloading the zip file from this page
 - To get automatic update you can download and install my repository from https://github.com/chamchenko/repository.chamchenko

## What Works
 - Live TV
 - Free TV Shows & TV Programs
 - Premium Content
 - Add To My List (adding content to shahid My List)
 - Add To Librart (exporting movies and tv shows to Kodi Library)
 - Kids Mode available throught the add-on settings
 - Kids Mode is protected with pin code when account info are provided
## To-Do
 - tv integration for live channels

## Titles not displayed?
 - most of the title are in arabic. for kodi to display them correctly you need to change the fonts settings to arial based
 Settings->Interface->Skin->Fonts set it to arial based
