# AD TV Kodi plguin

Live Streaming, VOD, AD TV, TV Shows and TV Programs from https://adtv.ae

## Install tips
 - You can install this plugin by downloading the zip file from this page
 - To get automatic update you can download and install my repository from https://github.com/chamchenko/repository.chamchenko
 - Inputstream Adaptive is needed as well as libwidevine 
