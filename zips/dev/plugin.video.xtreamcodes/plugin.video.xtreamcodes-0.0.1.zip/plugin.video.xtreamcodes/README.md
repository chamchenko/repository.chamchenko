This Add-on aims to provide an easy way to access IPTV subscriptions making use of Xtream codes API. This Add-on does not provide any content. This Add-on developers does not encourage piracy nor provide any right protected content This Add-on developer does not take responsibility for the content users may access using it

To Do:
- Integration with IPTV pvr simple.
- Export Movies and TV Shows to library
- Fetching EPG
