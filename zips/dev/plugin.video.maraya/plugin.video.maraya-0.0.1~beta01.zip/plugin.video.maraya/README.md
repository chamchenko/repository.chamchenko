# Maraya Kodi plguin

Live Streaming, VOD, Awaan, TV Shows and TV Programs from https://maraya.sba.net.ae/

## Install tips
 - You can install this plugin by downloading the zip file from this page
 - To get automatic update you can download and install my repository from https://github.com/chamchenko/repository.chamchenko
