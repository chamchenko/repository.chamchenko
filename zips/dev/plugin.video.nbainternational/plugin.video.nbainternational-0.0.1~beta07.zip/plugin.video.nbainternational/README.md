# NBA International Kodi plguin

- Live NBA TV, Live and Archive Games, Videos Collections and more
- NBA International League Pass is needed

## Install tips
 - You can install this plugin by downloading the zip file from this page
 - To get automatic update you can download and install my repository from https://github.com/chamchenko/repository.chamchenko

## What Works
 - Live NBA TV
 - Videos Collections and NBA TV Series
 - Browsing videos by team/player
 - Search across the nba videos database
## To-Do
 - Fix start point to Live games (play from the beginning / go live)
