# NBA International League Pass Kodi Plugin

- Live NBA Games, NBA TV, Archived Games, Video Collections and More
- Requires an Active NBA International League Pass Subscription

## Install tips
 - You can install the most up-to-date version of this plugin by downloading the zip file from the 'Dev' Branch on this page
 - To get automatic updates you can download and install my repository from https://github.com/chamchenko/repository.chamchenko

## What Works
 - Live NBA TV
 - Video Collections and NBA TV Series
 - Browsing videos by team/player
 - Search across the NBA videos database

## To-Do
 - Add possibility to chose within the settings to automatically go live/start from the beginning for live games
