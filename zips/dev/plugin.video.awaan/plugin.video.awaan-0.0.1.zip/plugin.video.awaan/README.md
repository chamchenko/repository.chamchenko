# Awaan Kodi plguin

Live Streaming, VOD, Awaan, TV Shows and TV Programs from https://www.awaan.ae

## Install tips
 - You can install this plugin by downloading the zip file from this page
 - To get automatic update you can download and install my repository from https://github.com/chamchenko/repository.chamchenko
 - Inputstream Adaptive is needed as well as libwidevine 

# By me a cofee
If you want to donate you can do it using this link down here
https://www.paypal.com/donate/?hosted_button_id=NB4C25J6ED3ZE
